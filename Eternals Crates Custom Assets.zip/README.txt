ETERNALS CRATES CUSTOM ASSETS

Minecraft version: 1.21.1

INSTALLATION
1. Put this folder or its ZIP into the client's resourcepacks folder.
2. Enable "Eternals Crates Custom Assets" above other packs.
3. Press F3+T after editing assets, or restart Minecraft.

EDITING
- models.json is an index showing which model belongs to each registered item.
- Actual Minecraft item models are in assets/eternals_crates/models/item.
- Claw-machine models are in assets/eternals_crates/models/block.
- PNG textures are in assets/eternals_crates/textures/item and textures/block.
- Keep registered model filenames unchanged.
- PNG files should retain transparency and use dimensions appropriate for Minecraft.

MULTIPLAYER
Every player must install this pack, or the server must distribute the ZIP through
the resource-pack settings in server.properties. The server cannot render models
for clients that do not possess the resource pack.

FALLBACK
The original assets remain bundled inside the mod JAR. Disabling this resource pack
restores those fallback models and textures.
